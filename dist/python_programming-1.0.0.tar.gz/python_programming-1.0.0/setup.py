from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.touls'],
    url='http://hayashikoki.com',
    license='Free',
    author='hayashikoki',
    author_email='',
    description='Sample package'
)
