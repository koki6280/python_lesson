# from lesson_package.touls import utils
from ..touls import utils

def sing():
    return 'sing'

def cry():
    return utils.say_twice('cry')