from lesson_package.touls import utils

def sing():
    return 'hhfdhsoojrsing'

def cry():
    return utils.say_twice('jhshohfosscry')